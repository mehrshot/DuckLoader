"""
Platform detection, media extraction, and audio tagging.

Instagram / YouTube / SoundCloud are downloaded directly with yt-dlp, which
supports all three natively, at one of three quality tiers:
  - "best"  — highest available quality, video+audio
  - "720p"  — capped at 720p, smaller file
  - "audio" — audio only, extracted to mp3

Spotify is different: Spotify's own audio streams are DRM-protected, so
there is no direct "download from Spotify" here. Instead, track metadata
(title, artist, album, cover art) is fetched from Spotify's official Web
API, and the matching audio is located and downloaded from YouTube. This is
the same approach the popular open-source spotDL project uses, and it never
touches Spotify's protected streams.
"""

import json
import os
import re

import yt_dlp

DOWNLOAD_DIR = "downloads"

PLATFORM_NAMES = {
    "instagram": "Instagram",
    "youtube": "YouTube",
    "soundcloud": "SoundCloud",
    "spotify": "Spotify",
}

PLATFORM_PATTERNS = {
    "instagram": re.compile(r"instagram\.com/\S+", re.IGNORECASE),
    "youtube": re.compile(r"(youtube\.com|youtu\.be)/\S+", re.IGNORECASE),
    "soundcloud": re.compile(r"soundcloud\.com/\S+", re.IGNORECASE),
    "spotify": re.compile(r"(open\.)?spotify\.com/\S+", re.IGNORECASE),
}

MAX_TELEGRAM_BYTES = 49 * 1024 * 1024  # a hair under Telegram's 50MB bot-upload cap

AUDIO_EXTENSIONS = {".mp3", ".m4a", ".opus", ".ogg", ".wav", ".flac"}
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mkv", ".mov"}

# Order matters: this is the fallback ladder auto_quality_fallback steps
# down through — each tier is smaller than the last, "audio" is the final
# safety net since audio-only is virtually always under Telegram's cap.
QUALITY_LADDER = ["best", "720p", "audio"]

QUALITY_FORMATS = {
    "best": "best",
    "720p": "best[height<=720]/best",
    "audio": "bestaudio/best",
}


class FileTooLargeError(Exception):
    pass


def detect_platform(text: str):
    """Returns the platform key for the first recognized link in `text`, or None."""
    for platform, pattern in PLATFORM_PATTERNS.items():
        if pattern.search(text):
            return platform
    return None


def media_kind(filepath: str) -> str:
    """Classifies a downloaded file so the bot knows whether to send it as a
    video, audio, or photo message."""
    ext = os.path.splitext(filepath)[1].lower()
    if ext in AUDIO_EXTENSIONS:
        return "audio"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    return "photo"


def _ffmpeg_location():
    """Optional explicit path to ffmpeg/ffprobe (set FFMPEG_LOCATION in .env).
    yt-dlp normally finds ffmpeg on PATH by itself; this is only needed when
    that lookup fails (e.g. PATH was updated but the terminal running the
    bot wasn't restarted)."""
    return os.environ.get("FFMPEG_LOCATION") or None


def _probe_size(url: str, quality: str):
    """Returns the estimated size in bytes for this quality tier, or None if
    yt-dlp can't tell in advance. Raises FileTooLargeError if it's definitely
    over Telegram's cap."""
    probe_opts = {
        "quiet": True, "no_warnings": True, "socket_timeout": 30,
        "noplaylist": False, "format": QUALITY_FORMATS[quality],
    }
    with yt_dlp.YoutubeDL(probe_opts) as ydl:
        info = ydl.extract_info(url, download=False)

    entries = info.get("entries") or [info]
    total, known = 0, False
    for entry in entries:
        size = entry.get("filesize") or entry.get("filesize_approx")
        if size:
            total += size
            known = True

    if known and total > MAX_TELEGRAM_BYTES:
        raise FileTooLargeError(f"{total / 1024 / 1024:.0f}MB")
    return total if known else None


def _download_at_quality(url: str, quality: str, progress_hook=None):
    ydl_opts = {
        "format": QUALITY_FORMATS[quality],
        "outtmpl": f"{DOWNLOAD_DIR}/%(id)s.%(ext)s",
        "quiet": True,
        "no_warnings": True,
        "color": "never",
        "noplaylist": False,
        "socket_timeout": 30,
    }
    if quality == "audio":
        ydl_opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }]
    ffmpeg_location = _ffmpeg_location()
    if ffmpeg_location:
        ydl_opts["ffmpeg_location"] = ffmpeg_location
    if progress_hook:
        ydl_opts["progress_hooks"] = [progress_hook]

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        entries = info["entries"] if info.get("_type") == "playlist" else [info]

        filepaths = []
        for entry in entries:
            raw_path = ydl.prepare_filename(entry)
            if quality == "audio":
                mp3_path = os.path.splitext(raw_path)[0] + ".mp3"
                filepaths.append(mp3_path if os.path.exists(mp3_path) else raw_path)
            else:
                filepaths.append(raw_path)

        return info, entries, filepaths


def download_direct(url: str, quality: str = "best", allow_fallback: bool = False, progress_hook=None):
    """Instagram / YouTube / SoundCloud — yt-dlp handles these natively.
    Returns (info, entries, filepaths, quality_used). If allow_fallback is
    True and the requested quality is too large, steps down the ladder
    (best -> 720p -> audio) until one fits, and reports which tier it
    actually used."""
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)

    start = QUALITY_LADDER.index(quality) if quality in QUALITY_LADDER else 0
    tiers_to_try = QUALITY_LADDER[start:] if allow_fallback else [quality]

    last_error = None
    for tier in tiers_to_try:
        try:
            _probe_size(url, tier)
        except FileTooLargeError as e:
            last_error = e
            continue
        info, entries, filepaths = _download_at_quality(url, tier, progress_hook)
        return info, entries, filepaths, tier

    raise last_error or FileTooLargeError("unknown size")


def get_spotify_client():
    import spotipy
    from spotipy.oauth2 import SpotifyClientCredentials

    auth = SpotifyClientCredentials(
        client_id=os.environ["SPOTIFY_CLIENT_ID"],
        client_secret=os.environ["SPOTIFY_CLIENT_SECRET"],
    )
    return spotipy.Spotify(client_credentials_manager=auth)


def _track_info(t: dict, album: dict | None = None) -> dict:
    album_data = album or t.get("album") or {}
    images = album_data.get("images") or []
    return {
        "name": t["name"],
        "artists": ", ".join(a["name"] for a in t.get("artists", [])),
        "album": album_data.get("name", ""),
        "cover_url": images[0]["url"] if images else None,
    }


def resolve_spotify_tracks(url: str) -> list:
    """Track/album/playlist metadata only, from Spotify's official Web API —
    no audio here yet."""
    sp = get_spotify_client()
    if "track/" in url:
        return [_track_info(sp.track(url))]
    if "album/" in url:
        album = sp.album(url)
        return [_track_info(t, album=album) for t in album["tracks"]["items"]]
    if "playlist/" in url:
        items = sp.playlist_items(url)["items"]
        return [_track_info(i["track"]) for i in items if i.get("track")]
    raise ValueError("Unsupported Spotify link — send a track, album, or playlist link.")


def download_spotify_track(track: dict, progress_hook=None) -> str:
    """Finds and downloads the best-matching YouTube audio for a Spotify
    track, converts it to mp3, and tags it with Spotify's own metadata
    (more accurate than whatever title YouTube has). Returns the file path."""
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    query = f"ytsearch1:{track['artists']} - {track['name']} audio"

    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": f"{DOWNLOAD_DIR}/%(id)s.%(ext)s",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 30,
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
    }
    ffmpeg_location = _ffmpeg_location()
    if ffmpeg_location:
        ydl_opts["ffmpeg_location"] = ffmpeg_location
    if progress_hook:
        ydl_opts["progress_hooks"] = [progress_hook]

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(query, download=True)
        entry = info["entries"][0] if info.get("_type") == "playlist" else info
        raw_path = ydl.prepare_filename(entry)

    mp3_path = os.path.splitext(raw_path)[0] + ".mp3"
    filepath = mp3_path if os.path.exists(mp3_path) else raw_path

    tag_audio_file(filepath, title=track["name"], artist=track["artists"],
                    album=track["album"], cover_url=track["cover_url"])
    return filepath


def tag_audio_file(filepath: str, title: str = "", artist: str = "", album: str = "", cover_url: str | None = None) -> None:
    """Writes ID3 tags (and cover art, if a URL is given) directly into an
    mp3 file. Best-effort: tagging failures are swallowed rather than
    breaking a download that otherwise succeeded."""
    if not filepath.lower().endswith(".mp3"):
        return
    try:
        from mutagen.id3 import ID3, ID3NoHeaderError, TIT2, TPE1, TALB, APIC

        try:
            tags = ID3(filepath)
        except ID3NoHeaderError:
            tags = ID3()

        if title:
            tags["TIT2"] = TIT2(encoding=3, text=title)
        if artist:
            tags["TPE1"] = TPE1(encoding=3, text=artist)
        if album:
            tags["TALB"] = TALB(encoding=3, text=album)

        if cover_url:
            import urllib.request
            with urllib.request.urlopen(cover_url, timeout=10) as resp:
                cover_bytes = resp.read()
            tags["APIC"] = APIC(encoding=3, mime="image/jpeg", type=3, desc="Cover", data=cover_bytes)

        tags.save(filepath)
    except Exception:
        pass
