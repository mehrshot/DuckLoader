"""
Telegram bot that downloads public Instagram posts/reels and sends them back
to the user.

Setup
-----
    pip install pyTelegramBotAPI yt-dlp

Set your bot token as an environment variable instead of hardcoding it
(get a fresh one from @BotFather first — your old one is compromised):

    export BOT_TOKEN="your-new-token-from-BotFather"     # macOS / Linux
    setx BOT_TOKEN "your-new-token-from-BotFather"        # Windows

Why yt-dlp instead of api.cobalt.tools
---------------------------------------
The public api.cobalt.tools instance sits behind Cloudflare Turnstile bot
protection, and its own docs say it isn't meant for third-party bots without
permission. A plain `requests.post` can never solve that challenge (it needs
a real browser), so that call was failing before it ever reached your logic.
yt-dlp talks to Instagram directly, is actively maintained, and needs no
external API dependency.

Notes
-----
- Handles public posts/reels with no login required.
- Private accounts or Stories need a cookies file passed via yt-dlp's
  `cookiefile` option (see the yt-dlp docs). If you use this, export a
  *fresh* cookies file from your own account, keep it out of any shared or
  public code (add it to .gitignore), and know that heavy automated use can
  still get that account rate-limited or flagged — it's the most fragile of
  the options for a bot that many people will use.
- The strings below ("Send me an Instagram link.", etc.) are in English to
  match your original file — swap them for Persian if your bot's audience
  is Persian-speaking.
"""

import logging
import os

import telebot
import yt_dlp

import bot_features

BOT_TOKEN = "***"

#BOT_TOKEN = os.environ["BOT_TOKEN"]  # never hardcode this — see the setup notes above
DOWNLOAD_DIR = "downloads"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = telebot.TeleBot(BOT_TOKEN)

bot_features.register_features(bot)

if __name__ == "__main__":
    bot.infinity_polling()

YDL_OPTS = {
    "format": "best",  # best single muxed stream — Instagram rarely needs an ffmpeg merge
    "outtmpl": f"{DOWNLOAD_DIR}/%(id)s.%(ext)s",
    "quiet": True,
    "no_warnings": True,
    "noplaylist": True,  # carousels: grab the first item only, same as your original code
    "socket_timeout": 30,
}


def download_instagram_video(url: str) -> str:
    """Downloads the given Instagram URL with yt-dlp and returns the local file path."""
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    with yt_dlp.YoutubeDL(YDL_OPTS) as ydl:
        info = ydl.extract_info(url, download=True)
        return ydl.prepare_filename(info)


@bot.message_handler(commands=["start"])
def send_welcome(message):
    bot.reply_to(message, "Send me an Instagram link.")


@bot.message_handler(func=lambda msg: bool(msg.text) and "instagram.com" in msg.text)
def handle_instagram_link(message):
    url = message.text.strip()
    chat_id = message.chat.id
    status_msg = bot.reply_to(message, "Downloading...")

    filepath = None
    try:
        filepath = download_instagram_video(url)

        with open(filepath, "rb") as video_file:
            bot.send_video(chat_id, video_file, timeout=120)

        bot.delete_message(chat_id, status_msg.message_id)

    except Exception as e:
        # Logged in full server-side, shown short in the chat — same spirit as your
        # original file, but this branch now always fires instead of sometimes
        # leaving the "Downloading..." message stuck with no explanation.
        logger.exception("Failed to process %s", url)
        bot.edit_message_text(f"Failed: {e}", chat_id, status_msg.message_id)

    finally:
        # Guarantees cleanup even if send_video raises partway through.
        if filepath and os.path.exists(filepath):
            os.remove(filepath)


if __name__ == "__main__":
    bot.infinity_polling()