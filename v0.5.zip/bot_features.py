import os
import time
import re
import json
from datetime import datetime
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import yt_dlp

DOWNLOAD_DIR = "downloads"
SETTINGS_FILE = "user_settings.json"
thumb_cache = {}

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_settings(prefs):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(prefs, f, ensure_ascii=False, indent=4)

user_prefs = load_settings()

TEXTS = {
    'fa': {
        'welcome': "🎯 **به DropShot DL خوش آمدید!**\n\nلینک پابلیک اینستاگرام (ریلز، پست، اسلاید) را بفرستید تا با بالاترین کیفیت دانلود کنم.",
        'init': "⏳ در حال برقراری ارتباط...",
        'downloading': "🔄 **در حال دانلود**\n\n📦 حجم: {size}\n🚀 پیشرفت: {percent}\n⏱ زمان: {eta}",
        'uploading': "✅ دانلود تکمیل شد! در حال آپلود...",
        'failed': "❌ خطا: {error}",
        'view_ig': "🔗 مشاهده پست در اینستاگرام",
        'dl_cover': "🖼 دانلود کاور",
        'cover_loading': "⏳ در حال دریافت کاور...",
        'cover_error': "⚠️ کاور این پست یافت نشد.",
        'settings_msg': "⚙️ **تنظیمات ربات**\n\nلطفاً زبان خود را انتخاب کنید:",
    },
    'en': {
        'welcome': "🎯 **Welcome to DropShot DL!**\n\nSend me any public Instagram link (Reel, Post, or Carousel) and I will fetch it in high quality.",
        'init': "⏳ Initializing connection...",
        'downloading': "🔄 **Downloading Media**\n\n📦 Size: {size}\n🚀 Progress: {percent}\n⏱ ETA: {eta}",
        'uploading': "✅ Download complete! Preparing upload...",
        'failed': "❌ Failed: {error}",
        'view_ig': "🔗 View Post on Instagram",
        'dl_cover': "🖼 Download Cover",
        'cover_loading': "⏳ Fetching cover...",
        'cover_error': "⚠️ Cover not found.",
        'settings_msg': "⚙️ **Bot Settings**\n\nPlease select your preferred language:",
    }
}

def register_features(bot):

    @bot.message_handler(commands=["start", "help"])
    def send_welcome(message):
        chat_id = str(message.chat.id)
        lang = user_prefs.get(chat_id, 'fa')
        bot.reply_to(message, TEXTS[lang]['welcome'], parse_mode="Markdown")

    @bot.message_handler(commands=["settings"])
    def open_settings(message):
        chat_id = str(message.chat.id)
        lang = user_prefs.get(chat_id, 'fa')
        
        markup = InlineKeyboardMarkup()
        fa_text = "🇮🇷 فارسی ✅" if lang == 'fa' else "🇮🇷 فارسی"
        en_text = "🇺🇸 English ✅" if lang == 'en' else "🇺🇸 English"
        
        markup.add(
            InlineKeyboardButton(text=fa_text, callback_data="lang_fa"),
            InlineKeyboardButton(text=en_text, callback_data="lang_en")
        )
        
        bot.reply_to(message, TEXTS[lang]['settings_msg'], reply_markup=markup, parse_mode="Markdown")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('lang_'))
    def handle_language_switch(call):
        new_lang = call.data.split('_')[1]
        chat_id = str(call.message.chat.id)
        
        user_prefs[chat_id] = new_lang
        save_settings(user_prefs)
        
        markup = InlineKeyboardMarkup()
        fa_text = "🇮🇷 فارسی ✅" if new_lang == 'fa' else "🇮🇷 فارسی"
        en_text = "🇺🇸 English ✅" if new_lang == 'en' else "🇺🇸 English"
        markup.add(
            InlineKeyboardButton(text=fa_text, callback_data="lang_fa"),
            InlineKeyboardButton(text=en_text, callback_data="lang_en")
        )
        
        bot.edit_message_text(
            TEXTS[new_lang]['settings_msg'], 
            int(chat_id), 
            call.message.message_id, 
            reply_markup=markup, 
            parse_mode="Markdown"
        )
        bot.answer_callback_query(call.id)

    @bot.message_handler(func=lambda msg: bool(msg.text) and "instagram.com" in msg.text)
    def handle_instagram_link(message):
        chat_id_str = str(message.chat.id)
        chat_id_int = message.chat.id
        lang = user_prefs.get(chat_id_str, 'fa')
        t = TEXTS[lang]
        
        url = message.text.strip()
        status_msg = bot.reply_to(message, t['init'])

        last_edit_time = 0

        def progress_hook(d):
            nonlocal last_edit_time
            if d.get('status') == 'downloading':
                now = time.time()
                if now - last_edit_time > 2.0:
                    percent = d.get('_percent_str', 'N/A').strip()
                    eta = d.get('_eta_str', 'N/A').strip()
                    size = d.get('_total_bytes_str') or d.get('_estimated_total_bytes_str', 'N/A')
                    if isinstance(size, str):
                        size = size.strip()
                    
                    log_text = t['downloading'].format(size=size, percent=percent, eta=eta)
                    try:
                        bot.edit_message_text(log_text, chat_id_int, status_msg.message_id, parse_mode="Markdown")
                    except Exception:
                        pass
                    last_edit_time = now

        ydl_opts = {
            "format": "best",
            "outtmpl": f"{DOWNLOAD_DIR}/%(id)s.%(ext)s",
            "quiet": True,
            "no_warnings": True,
            "color": "never",
            "noplaylist": False,
            "socket_timeout": 30,
            "progress_hooks": [progress_hook]
        }

        try:
            os.makedirs(DOWNLOAD_DIR, exist_ok=True)
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
            
            bot.edit_message_text(t['uploading'], chat_id_int, status_msg.message_id)

            entries = []
            if info.get('_type') == 'playlist':
                entries = info.get('entries', [])
            else:
                entries = [info]

            metadata_source = entries[0] if entries else info
            
            uploader = info.get('uploader') or metadata_source.get('uploader', 'Unknown')
            safe_hashtag = re.sub(r'\W+', '_', uploader)
            
            timestamp = info.get('timestamp') or metadata_source.get('timestamp')
            date_str = datetime.fromtimestamp(timestamp).strftime('%Y/%m/%d, %H:%M') if timestamp else "Unknown"
            
            likes = info.get('like_count') or metadata_source.get('like_count') or 0
            comments = info.get('comment_count') or metadata_source.get('comment_count') or 0
            views = info.get('view_count') or metadata_source.get('view_count') or 0
            
            def format_num(n):
                return f"{n:,}" if isinstance(n, int) else n

            stats_line = f"❤️ {format_num(likes)} | 💬 {format_num(comments)} | 👁‍🗨 {format_num(views)}"
            
            description = info.get('description') or metadata_source.get('description', '')
            max_length = 750
            if len(description) > max_length:
                description = description[:max_length] + "..."
            
            final_caption = (
                f"#{safe_hashtag}\n"
                f"👤 {uploader}\n"
                f"📅 {date_str}\n"
                f"{stats_line}\n\n"
                f"📝 {description}\n\n"
                f"🤖 @DropShotDLBot"
            )

            post_id = info.get('id') or metadata_source.get('id', str(time.time()))
            thumb_url = info.get('thumbnail') or metadata_source.get('thumbnail')
            if thumb_url:
                thumb_cache[post_id] = thumb_url

            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton(text=t['view_ig'], url=url))
            if thumb_url:
                markup.add(InlineKeyboardButton(text=t['dl_cover'], callback_data=f"thumb_{post_id}"))

            for j, entry in enumerate(entries):
                filepath = ydl.prepare_filename(entry)
                if not os.path.exists(filepath):
                    continue
                
                caption_to_send = final_caption if j == 0 else ""
                current_markup = markup if j == 0 else None
                
                with open(filepath, "rb") as media_file:
                    if filepath.endswith(".mp4") or filepath.endswith(".webm"):
                        bot.send_video(chat_id_int, media_file, caption=caption_to_send, reply_markup=current_markup, reply_to_message_id=message.message_id, timeout=120)
                    else:
                        bot.send_photo(chat_id_int, media_file, caption=caption_to_send, reply_markup=current_markup, reply_to_message_id=message.message_id)
                
                os.remove(filepath)

            bot.delete_message(chat_id_int, status_msg.message_id)

        except Exception as e:
            try:
                bot.edit_message_text(t['failed'].format(error=str(e)), chat_id_int, status_msg.message_id)
            except Exception:
                pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('thumb_'))
    def handle_thumbnail_callback(call):
        chat_id = str(call.message.chat.id)
        lang = user_prefs.get(chat_id, 'fa')
        t = TEXTS[lang]
        
        post_id = call.data.split('thumb_')[1]
        thumb_url = thumb_cache.get(post_id)
        
        if thumb_url:
            bot.answer_callback_query(call.id, t['cover_loading'])
            bot.send_photo(int(chat_id), thumb_url, reply_to_message_id=call.message.message_id)
        else:
            bot.answer_callback_query(call.id, t['cover_error'], show_alert=True)